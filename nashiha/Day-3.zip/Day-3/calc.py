def add(a,b):
    sum = a+b
    return sum
def sub(a,b):
    sub = a-b
    return sub
def mul(a,b):
    mul = a*b
    return mul
x = int(input("Enter a number1: "))
y = int(input("Enter another number2: "))
print(f"the addition of numbers is: {add(x,y)} ")
print(f"the addition of numbers is: {sub(x,y)} ")
print(f"the addition of numbers is: {mul(x,y)} ")