import random
def rand():
    ran = random.randint(1,7)
    print(ran)
    x, y, z =["apple", "banana", "plums"]
    print(x+y+z)
rand()