import sys

print (type(8))
print (type(7+2j))
print (type({'name': 'Isabella'}))
print (type("lilly"))
print(type((2, 3, 810)))
print(sys.version)
